class MicroChart{
  constructor(id, opts={}){
    const el = document.getElementById(id);
    this.ctx = el ? el.getContext('2d') : null;
    this.labels=[]; this.values=[];
    this.type = opts.type || 'bar';
  }
  set(labels, values){
    this.labels = labels || [];
    this.values = values || [];
    if(!this.ctx) return;
    const ctx = this.ctx;
    const w = ctx.canvas.width, h = ctx.canvas.height;
    ctx.clearRect(0,0,w,h);
    const vals = this.values.map(v=>Number(v)||0);
    if(this.type==='pie' || this.type==='doughnut'){
      const total = vals.reduce((a,b)=>a+b,0) || 1;
      let ang = -Math.PI/2;
      const R = Math.min(w,h)/2 - 6;
      const cx = w/2, cy = h/2;
      vals.forEach((v,i)=>{
        const frac = v/total;
        const a2 = ang + frac*2*Math.PI;
        ctx.beginPath();
        ctx.moveTo(cx,cy);
        ctx.arc(cx,cy,R,ang,a2);
        ctx.closePath();
        ctx.fillStyle = `hsl(${(i*65)%360} 70% 50%)`;
        ctx.fill();
        ang = a2;
      });
      if(this.type==='doughnut'){
        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.arc(cx,cy,R*0.55,0,Math.PI*2);
        ctx.fill();
      }
      return;
    }
    // bar chart
    const max = Math.max(1, ...vals);
    const pad = 8;
    const n = vals.length;
    const cw = (w - pad*2) / Math.max(1,n);
    vals.forEach((v,i)=>{
      const bh = (v/max)*(h-20);
      ctx.fillStyle = `hsl(${(i*65)%360} 70% 50%)`;
      ctx.fillRect(pad + i*cw, h-bh-10, cw*0.75, bh);
    });
  }
}