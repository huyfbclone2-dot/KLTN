#!/usr/bin/env bash
set -euo pipefail
mkdir -p static
uvicorn app:app --host 127.0.0.1 --port ${PORT:-3221} --reload
