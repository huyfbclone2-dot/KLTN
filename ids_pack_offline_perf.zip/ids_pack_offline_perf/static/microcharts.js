
// super tiny bar chart renderer (canvas 2D) — no external deps
(function(){
  function BarChart(canvasId){
    this.canvas = document.getElementById(canvasId);
    if(!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');
    this.data = [];
    this.labels = [];
  }
  BarChart.prototype.set = function(labels, values){
    this.labels = labels || [];
    this.data = values || [];
    this.draw();
  };
  BarChart.prototype.draw = function(){
    const c = this.canvas, ctx = this.ctx;
    if(!c || !ctx) return;
    const W = c.width, H = c.height;
    ctx.clearRect(0,0,W,H);
    const n = this.data.length;
    if(!n) return;
    const max = Math.max.apply(null, this.data.map(Number));
    const pad = 24, barW = Math.max(2, (W - pad*2) / Math.max(1,n) * 0.75);
    ctx.fillStyle = '#3b82f6';
    for(let i=0;i<n;i++){
      const v = Number(this.data[i]||0);
      const h = max>0 ? Math.round((H - pad*2) * (v/max)) : 0;
      const x = pad + i * ((W - pad*2)/Math.max(1,n));
      const y = H - pad - h;
      ctx.fillRect(x, y, barW, h);
    }
  };
  window.MicroChart = BarChart;
})();
