from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os
from datetime import datetime, timezone
from typing import List, Dict, Any

# orjson để parse nhanh (fallback json nếu không có)
try:
    import orjson as _json
    def _loads(b): return _json.loads(b)
except Exception:
    import json as _json
    def _loads(b): return _json.loads(b)

# ==== ĐƯỜNG DẪN CỐ ĐỊNH ====
ALERTS_PATH = "/home/kali/web/runs/realtime/alerts.jsonl"
SCORES_PATH = "/home/kali/web/runs/realtime/alerts.jsonl"

# ==== Tham số hiệu năng (đổi qua ENV nếu muốn) ====
REFRESH_SEC    = int(os.environ.get("REFRESH_SEC", "2"))
TAIL_MAX_LINES = int(os.environ.get("TAIL_MAX_LINES", "120000"))
RECENT_ROWS    = int(os.environ.get("RECENT_ROWS", "400"))
TOPK           = int(os.environ.get("TOPK", "10"))

app = FastAPI(title="IDS AI Dashboard (offline, perf)", version="1.1.1")
templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))

static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.isdir(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")


# ---- Tail nhanh cuối file lớn ----
def _tail_lines(path: str, n: int) -> List[bytes]:
    if not os.path.exists(path): return []
    size = os.path.getsize(path)
    if size <= 0: return []
    block = 1 << 16  # 64KB
    data = bytearray()
    with open(path, "rb") as f:
        pos = max(size - block, 0)
        while True:
            f.seek(pos)
            chunk = f.read(block)
            data.extend(chunk)
            if data.count(b"\n") >= n + 1 or pos == 0:
                break
            pos = max(pos - block, 0)
    return data.splitlines()[-n:]


def _read_jsonl(path: str, limit: int) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for ln in _tail_lines(path, limit):
        try:
            rows.append(_loads(ln))
        except Exception:
            # bỏ qua dòng hỏng/truncated khi file đang được ghi tiếp
            continue
    return rows


def _to_float_ts(x):
    """Trả về timestamp dạng float (s), hỗ trợ: số, '1234.56', ISO 8601."""
    try:
        if isinstance(x, (int, float)):
            return float(x)
        s = str(x).strip()
        # chuỗi số / số thực
        try:
            return float(s)
        except Exception:
            pass
        # ISO 8601 -> timestamp
        return datetime.fromisoformat(s.replace('Z', '+00:00')).timestamp()
    except Exception:
        return None


def _to_iso_local(x):
    """Đưa về chuỗi thời gian Local (YYYY-MM-DD HH:MM:SS)."""
    try:
        if isinstance(x, (int, float)):
            return datetime.fromtimestamp(float(x)).isoformat(sep=' ', timespec='seconds')
        s = str(x).replace('Z', '+00:00')
        d = datetime.fromisoformat(s)
        return d.astimezone().isoformat(sep=' ', timespec='seconds')
    except Exception:
        return str(x)


def _num(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    # PHẢI truyền request thật vào TemplateResponse
    return templates.TemplateResponse("index.html", {"request": request, "refresh_ms": REFRESH_SEC * 1000})


@app.get("/api/summary")
def api_summary():
    rows = _read_jsonl(ALERTS_PATH, TAIL_MAX_LINES)
    total = len(rows)
    alerts = 0
    max_ts = None
    top_ports: Dict[str, int] = {}
    scores_hist: Dict[str, int] = {}
    by_proto: Dict[str, int] = {}
    recent: List[Dict[str, Any]] = []

    def add_hist(score: float):
        b = int(max(0, min(9, score * 10)))
        key = f"{b/10:.1f}-{(b+1)/10:.1f}"
        scores_hist[key] = scores_hist.get(key, 0) + 1

    # bảng recent lấy cửa sổ rộng rồi lọc ưu tiên alert
    base_recent = []
    tail_for_table = rows[-(RECENT_ROWS * 6 or 1):] if rows else []
    for r in tail_for_table:
        base_recent.append({
            "Timestamp": r.get("Timestamp") or r.get("ts") or "",
            "SrcIP": r.get("SrcIP") or r.get("src_ip") or r.get("src") or "",
            "DstIP": r.get("DstIP") or r.get("dst_ip") or r.get("dst") or "",
            "Protocol": r.get("Protocol") or r.get("proto") or "",
            "DestinationPort": r.get("DestinationPort") or r.get("dst_port") or r.get("port") or "",
            "score": r.get("score"),
            "pred": r.get("pred") or r.get("pred_attack") or 0,
        })

    for r in rows:
        # cập nhật max_ts an toàn
        ts_raw = r.get("Timestamp") or r.get("ts")
        fts = _to_float_ts(ts_raw)
        if fts is not None and (max_ts is None or fts > max_ts):
            max_ts = fts

        # đếm thống kê
        pred = int(_num(r.get("pred") or r.get("pred_attack"), 0))
        alerts += pred

        # Top port & protocol chỉ tính trên alert
        port = r.get("DestinationPort") or r.get("dst_port") or r.get("port")
        if port not in (None, "") and pred == 1:
            try:
                p = str(int(float(port)))
                top_ports[p] = top_ports.get(p, 0) + 1
            except Exception:
                pass

        sc = r.get("score")
        if sc is not None:
            add_hist(_num(sc))

        proto = r.get("Protocol") or r.get("proto")
        if proto and pred == 1:
            k = str(proto).upper()
            by_proto[k] = by_proto.get(k, 0) + 1

    # mốc thời gian cuối cùng (mới nhất) trong cửa sổ
    last_ts = _to_iso_local(max_ts) if max_ts is not None else ""

    top_ports_arr = [{"port": k, "count": v} for k, v in sorted(top_ports.items(), key=lambda kv: kv[1], reverse=True)[:TOPK]]
    scores_hist_arr = [{"bin": k, "count": v} for k, v in sorted(scores_hist.items(), key=lambda kv: kv[0])]
    by_proto_arr = [{"proto": k, "count": v} for k, v in sorted(by_proto.items(), key=lambda kv: kv[1], reverse=True)[:TOPK]]

    recent_all = [r for r in base_recent if int(_num(r["pred"], 0)) == 1]
    if len(recent_all) < RECENT_ROWS:
        recent_all += [r for r in base_recent if int(_num(r["pred"], 0)) != 1]
    recent = recent_all[-RECENT_ROWS:]

    return JSONResponse({
        "total": total,
        "alerts": alerts,
        "alert_rate": (alerts / total) if total else 0.0,
        "last_ts": last_ts,
        "top_resp_ports": top_ports_arr,
        "scores_hist": scores_hist_arr,
        "by_proto": by_proto_arr,
        "recent": recent
    })


@app.get("/api/alerts")
def api_alerts(limit: int = 2000):
    rows = _read_jsonl(ALERTS_PATH, min(TAIL_MAX_LINES, 5 * limit))
    rows = [r for r in rows if int(_num(r.get("pred") or r.get("pred_attack"), 0)) == 1]
    return JSONResponse(rows[-limit:])


@app.get("/api/scores")
def api_scores(limit: int = 2000):
    rows = _read_jsonl(SCORES_PATH, min(TAIL_MAX_LINES, 5 * limit))
    return JSONResponse(rows[-limit:])


@app.get("/healthz")
def health():
    ok = os.path.exists(ALERTS_PATH) or os.path.exists(SCORES_PATH)
    return {"ok": ok, "alerts_path": ALERTS_PATH, "scores_path": SCORES_PATH, "refresh_sec": REFRESH_SEC}


@app.get("/README", response_class=HTMLResponse)
def readme(request: Request):
    return templates.TemplateResponse("readme.html", {"request": request})
