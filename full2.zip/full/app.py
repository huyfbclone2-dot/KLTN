from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os
from datetime import datetime
from typing import List, Dict, Any

# orjson để parse nhanh (fallback json nếu không có)
try:
    import orjson as _json
    def _loads(b): return _json.loads(b)
except Exception:
    import json as _json
    def _loads(b): return _json.loads(b)

# ==== ĐƯỜNG DẪN CỐ ĐỊNH ====
ALERTS_PATH = os.environ.get("ALERTS_PATH", "/home/kali/web/runs/realtime/alerts.jsonl")
SCORES_PATH = os.environ.get("SCORES_PATH", ALERTS_PATH)

# ==== Tham số hiệu năng (đổi qua ENV nếu muốn) ====
REFRESH_SEC    = int(os.environ.get("REFRESH_SEC", "2"))
TAIL_MAX_LINES = int(os.environ.get("TAIL_MAX_LINES", "120000"))
RECENT_ROWS    = int(os.environ.get("RECENT_ROWS", "40"))
TOPK           = int(os.environ.get("TOPK", "10"))
SCAN_PORTS_MIN = int(os.environ.get("SCAN_PORTS_MIN", "10"))   # số port khác nhau để coi là port-scan
DOS_SOURCES_MIN= int(os.environ.get("DOS_SOURCES_MIN", "30"))  # số nguồn khác nhau cùng đánh 1 port để coi là dos-like

app = FastAPI(title="IDS AI Dashboard (Option A + heatmap + rules)", version="1.3.0")
templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))

static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.isdir(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")


# ---- Tail nhanh cuối file lớn ----
def _tail_lines(path: str, n: int) -> List[bytes]:
    if not os.path.exists(path): return []
    size = os.path.getsize(path)
    if size <= 0: return []
    block = 1 << 16  # 64KB
    data = bytearray()
    with open(path, "rb") as f:
        pos = max(size - block, 0)
        while True:
            f.seek(pos)
            chunk = f.read(block)
            data.extend(chunk)
            if data.count(b"\n") >= n + 1 or pos == 0:
                break
            pos = max(pos - block, 0)
    return data.splitlines()[-n:]


def _read_jsonl(path: str, limit: int) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for ln in _tail_lines(path, limit):
        try:
            rows.append(_loads(ln))
        except Exception:
            continue
    return rows


def _to_float_ts(x):
    try:
        if isinstance(x, (int, float)):
            return float(x)
        s = str(x).strip()
        try:
            return float(s)
        except Exception:
            pass
        return datetime.fromisoformat(s.replace('Z', '+00:00')).timestamp()
    except Exception:
        return None


def _to_iso_local(x):
    try:
        if isinstance(x, (int, float)):
            return datetime.fromtimestamp(float(x)).isoformat(sep=' ', timespec='seconds')
        s = str(x).replace('Z', '+00:00')
        d = datetime.fromisoformat(s)
        return d.astimezone().isoformat(sep=' ', timespec='seconds')
    except Exception:
        return str(x)


def _num(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    html_path = os.path.join(os.path.dirname(__file__), "index.html")
    with open(html_path, "r", encoding="utf-8") as f:
        return HTMLResponse(f.read())


@app.get("/api/summary")
def api_summary():
    rows = _read_jsonl(ALERTS_PATH, TAIL_MAX_LINES)
    total = len(rows)
    alerts = 0
    max_ts = None
    top_ports: Dict[str, int] = {}
    scores_hist: Dict[str, int] = {}
    by_proto: Dict[str, int] = {}
    recent: List[Dict[str, Any]] = []

    # ---- gom để phục vụ rule-based ----
    src_to_ports = {}
    port_to_src  = {}

    def add_hist(score: float):
        b = int(max(0, min(9, score * 10)))
        key = f"{b/10:.1f}-{(b+1)/10:.1f}"
        scores_hist[key] = scores_hist.get(key, 0) + 1

    base_recent = []
    tail_for_table = rows[-(RECENT_ROWS * 6 or 1):] if rows else []
    for r in tail_for_table:
        base_recent.append({
            "Timestamp": r.get("Timestamp") or r.get("ts") or "",
            "SrcIP": r.get("SrcIP") or r.get("src_ip") or r.get("src") or "",
            "DstIP": r.get("DstIP") or r.get("dst_ip") or r.get("dst") or "",
            "Protocol": r.get("Protocol") or r.get("proto") or "",
            "DestinationPort": r.get("DestinationPort") or r.get("dst_port") or r.get("port") or "",
            "score": r.get("score"),
            "pred": r.get("pred") or r.get("pred_attack") or 0,
        })

    for r in rows:
        ts_raw = r.get("Timestamp") or r.get("ts")
        fts = _to_float_ts(ts_raw)
        if fts is not None and (max_ts is None or fts > max_ts):
            max_ts = fts

        pred = int(_num(r.get("pred") or r.get("pred_attack"), 0))
        alerts += pred

        port_raw = r.get("DestinationPort") or r.get("dst_port") or r.get("port")
        proto = r.get("Protocol") or r.get("proto")

        if port_raw not in (None, "") and pred == 1:
            try:
                p = int(float(port_raw))
                top_ports[str(p)] = top_ports.get(str(p), 0) + 1

                # build for rules
                src = r.get("SrcIP") or r.get("src_ip") or r.get("src") or ""
                if src:
                    src_to_ports.setdefault(src, set()).add(p)
                    port_to_src.setdefault(p, set()).add(src)

            except Exception:
                pass

        sc = r.get("score")
        if sc is not None:
            add_hist(_num(sc))

        if proto and pred == 1:
            k = str(proto).upper()
            by_proto[k] = by_proto.get(k, 0) + 1

    last_ts = _to_iso_local(max_ts) if max_ts is not None else ""

    # ---- RULES ----
    rules_detected = []
    rules_pie_counts: Dict[str, int] = {}

    for src, ports in src_to_ports.items():
        if 21 in ports:
            rules_detected.append({"src": src, "rule": "ftp-attack", "port": 21})
            rules_pie_counts["ftp-attack"] = rules_pie_counts.get("ftp-attack", 0) + 1
        if len(ports) >= SCAN_PORTS_MIN:
            rules_detected.append({"src": src, "rule": "port-scan", "unique_ports": len(ports)})
            rules_pie_counts["port-scan"] = rules_pie_counts.get("port-scan", 0) + 1

    for port, srcs in port_to_src.items():
        if len(srcs) >= DOS_SOURCES_MIN:
            rules_detected.append({"port": port, "rule": "dos-like", "unique_src_ips": len(srcs)})
            rules_pie_counts["dos-like"] = rules_pie_counts.get("dos-like", 0) + 1

    rules_pie_arr = [{"rule": k, "count": v} for k, v in sorted(rules_pie_counts.items(), key=lambda kv: kv[1], reverse=True)]

    # dựng recent ưu tiên alert trước
    recent_all = [r for r in base_recent if int(_num(r["pred"], 0)) == 1]
    if len(recent_all) < RECENT_ROWS:
        recent_all += [r for r in base_recent if int(_num(r["pred"], 0)) != 1]
    recent = recent_all[-RECENT_ROWS:]

    top_ports_arr   = [{"port": k, "count": v} for k, v in sorted(top_ports.items(), key=lambda kv: kv[1], reverse=True)[:TOPK]]
    scores_hist_arr = [{"bin": k, "count": v} for k, v in sorted(scores_hist.items(), key=lambda kv: kv[0])]
    by_proto_arr    = [{"proto": k, "count": v} for k, v in sorted(by_proto.items(), key=lambda kv: kv[1], reverse=True)[:TOPK]]

    return JSONResponse({
        "total": total,
        "alerts": alerts,
        "alert_rate": (alerts / total) if total else 0.0,
        "last_ts": last_ts,
        "top_resp_ports": top_ports_arr,
        "scores_hist": scores_hist_arr,
        "by_proto": by_proto_arr,
        "recent": recent,
        "rules": rules_detected,
        "rules_pie": rules_pie_arr,
        "params": {
            "REFRESH_SEC": REFRESH_SEC,
            "SCAN_PORTS_MIN": SCAN_PORTS_MIN,
            "DOS_SOURCES_MIN": DOS_SOURCES_MIN
        }
    })


# ===== APIs MỚI =====
@app.get("/api/top_attackers")
def api_top_attackers(limit: int = 20):
    rows = _read_jsonl(ALERTS_PATH, TAIL_MAX_LINES)
    attackers = {}
    for r in rows:
        if int(_num(r.get("pred") or r.get("pred_attack"), 0)) == 1:
            src = r.get("SrcIP") or r.get("src") or r.get("src_ip") or ""
            if not src:
                continue
            attackers[src] = attackers.get(src, 0) + 1
    data = sorted(attackers.items(), key=lambda kv: kv[1], reverse=True)[:limit]
    return JSONResponse([{"ip": ip, "count": cnt} for ip, cnt in data])


@app.get("/api/top_attack_ports")
def api_top_attack_ports(limit: int = 20):
    rows = _read_jsonl(ALERTS_PATH, TAIL_MAX_LINES)
    ports = {}
    for r in rows:
        if int(_num(r.get("pred") or r.get("pred_attack"), 0)) == 1:
            port = r.get("DestinationPort") or r.get("dst_port") or r.get("port")
            try:
                port = int(float(port))
                ports[port] = ports.get(port, 0) + 1
            except Exception:
                pass
    data = sorted(ports.items(), key=lambda kv: kv[1], reverse=True)[:limit]
    return JSONResponse([{"port": p, "count": cnt} for p, cnt in data])


@app.get("/api/show_all")
def api_show_all(limit: int = 5000):
    rows = _read_jsonl(SCORES_PATH, min(limit, TAIL_MAX_LINES))
    return JSONResponse(rows[-limit:])


@app.get("/api/heatmap")
def api_heatmap(ip_limit: int = 10, port_limit: int = 10):
    """
    Trả về ma trận IP -> Port cho heatmap:
    {
      "ips":   ["ip1", "ip2", ...],
      "ports": [21, 22, 80, ...],
      "matrix": [[c11,c12,...],[c21,c22,...],...]
    }
    """
    rows = _read_jsonl(ALERTS_PATH, TAIL_MAX_LINES)

    pair_counts: Dict[tuple, int] = {}
    ip_totals: Dict[str, int] = {}
    port_totals: Dict[int, int] = {}

    for r in rows:
        if int(_num(r.get("pred") or r.get("pred_attack"), 0)) != 1:
            continue
        src = r.get("SrcIP") or r.get("src_ip") or r.get("src") or ""
        port_raw = r.get("DestinationPort") or r.get("dst_port") or r.get("port")
        if not src or port_raw in (None, ""):
            continue
        try:
            p = int(float(port_raw))
        except Exception:
            continue

        key = (src, p)
        pair_counts[key] = pair_counts.get(key, 0) + 1
        ip_totals[src] = ip_totals.get(src, 0) + 1
        port_totals[p] = port_totals.get(p, 0) + 1

    # chọn top IP và port
    top_ips = [ip for ip, _ in sorted(ip_totals.items(), key=lambda kv: kv[1], reverse=True)[:ip_limit]]
    top_ports = [port for port, _ in sorted(port_totals.items(), key=lambda kv: kv[1], reverse=True)[:port_limit]]

    matrix = []
    for ip in top_ips:
        row = []
        for p in top_ports:
            row.append(pair_counts.get((ip, p), 0))
        matrix.append(row)

    return JSONResponse({"ips": top_ips, "ports": top_ports, "matrix": matrix})


@app.get("/healthz")
def health():
    ok = os.path.exists(ALERTS_PATH) or os.path.exists(SCORES_PATH)
    return {"ok": ok, "alerts_path": ALERTS_PATH, "scores_path": SCORES_PATH, "refresh_sec": REFRESH_SEC}
