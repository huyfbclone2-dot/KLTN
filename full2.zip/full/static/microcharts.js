/* MicroChart v0.4 – show numbers clearly on bars & pies + simple legend */
class MicroChart{
  constructor(id, opts={}){
    const el = document.getElementById(id);
    this.canvas = el;
    this.ctx = el ? el.getContext('2d') : null;
    this.labels = [];
    this.values = [];
    this.type = opts.type || 'bar';
    this.maxLabels = opts.maxLabels || 16;   // hiển thị tối đa X nhãn trục X
    this.minPctText = opts.minPctText || 0.04; // hiển thị % nếu mảnh ≥ 4%

    // legend container bên dưới canvas
    const legendId = id + "_legend";
    let legend = document.getElementById(legendId);
    if(!legend){
      legend = document.createElement("div");
      legend.id = legendId;
      legend.style.fontSize = "12px";
      legend.style.marginTop = "8px";
      legend.style.color = "#334155";
      el.parentElement.appendChild(legend);
    }
    this.legendEl = legend;
  }

  _legend(pairs){
    // pairs = [[label, value], ...] – hiển thị tối đa 8 mục
    const top = pairs.slice(0, Math.min(8, pairs.length));
    this.legendEl.innerHTML = top.map(([lab,val], i)=>(
      `<span style="display:inline-block;margin:3px 10px 0 0">
         <span style="display:inline-block;width:10px;height:10px;background:hsl(${(i*65)%360} 70% 50%);margin-right:6px;border-radius:2px"></span>
         ${lab} <b>${Number(val||0).toLocaleString()}</b>
       </span>`
    )).join("");
  }

  set(labels, values){
    this.labels = (labels || []).map(String);
    this.values = (values || []).map(v => Number(v) || 0);

    if(!this.ctx) return;
    const ctx = this.ctx;
    const w = ctx.canvas.width, h = ctx.canvas.height;
    ctx.clearRect(0,0,w,h);

    // PIE / DOUGHNUT
    if(this.type==='pie' || this.type==='doughnut'){
      const total = this.values.reduce((a,b)=>a+b,0) || 1;
      let ang = -Math.PI/2;
      const R  = Math.min(w,h)/2 - 10;
      const cx = w/2, cy = h/2;

      const pairs = this.labels.map((l,i)=>[l, this.values[i]||0])
                               .sort((a,b)=>b[1]-a[1]);
      this._legend(pairs);

      this.values.forEach((v,i)=>{
        const frac = v/total;
        const a2 = ang + frac*2*Math.PI;
        ctx.beginPath(); ctx.moveTo(cx,cy);
        ctx.arc(cx,cy,R,ang,a2); ctx.closePath();
        ctx.fillStyle = `hsl(${(i*65)%360} 70% 50%)`;
        ctx.fill();

        // vẽ % bên trong lát
        if(frac >= this.minPctText){
          const mid = (ang + a2)/2;
          const rx  = cx + Math.cos(mid) * (this.type==='doughnut' ? R*0.72 : R*0.58);
          const ry  = cy + Math.sin(mid) * (this.type==='doughnut' ? R*0.72 : R*0.58);
          ctx.fillStyle = "#111827";
          ctx.font = "12px system-ui";
          const text = `${Math.round(frac*100)}%`;
          const m = ctx.measureText(text);
          ctx.fillText(text, rx - m.width/2, ry + 4);
        }
        ang = a2;
      });

      if(this.type==='doughnut'){
        ctx.fillStyle = "#fff";
        ctx.beginPath(); ctx.arc(cx,cy,R*0.55,0,Math.PI*2); ctx.fill();
      }
      return;
    }

    // BAR
    const vals = this.values;
    const max  = Math.max(1, ...vals);
    const padL = 30; // padding trái (đủ cho nhãn)
    const padB = 22; // padding đáy (trục X)
    const n = vals.length;
    const cw = (w - padL - 10) / Math.max(1,n);

    // lưới ngang nhẹ
    ctx.strokeStyle = "#e5e7eb";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for(let i=0;i<=4;i++){
      const y = h - padB - (i/4)*(h - padB - 10);
      ctx.moveTo(padL, y); ctx.lineTo(w-5, y);
    }
    ctx.stroke();

    // cột + số
    for(let i=0;i<n;i++){
      const val = vals[i];
      const bh  = (val/max) * (h - padB - 12);
      const x   = padL + i*cw;
      const y   = h - padB - bh;

      ctx.fillStyle = `hsl(${(i*65)%360} 70% 50%)`;
      ctx.fillRect(x+2, y, cw*0.78, bh);

      // số trên cột (không để vượt khung)
      const labelVal = Number(val||0).toLocaleString();
      ctx.fillStyle = "#111827";
      ctx.font = "11px system-ui";
      const m = ctx.measureText(labelVal);
      const ty = Math.max(12, y - 4); // không chạm mép trên
      ctx.fillText(labelVal, x + cw*0.39 - m.width/2, ty);
    }

    // nhãn trục X (chắc chắn nhìn thấy)
    ctx.fillStyle = "#64748b";
    ctx.font = "10px system-ui";
    const step = Math.ceil(n / this.maxLabels);
    for(let i=0;i<n;i+=step){
      const lab = this.labels[i];
      const m = ctx.measureText(lab);
      ctx.fillText(lab, padL + i*cw + cw*0.39 - m.width/2, h - 6); // nâng lên chút để không bị cắt
    }

    // legend = top theo giá trị
    const pairs = this.labels.map((l,i)=>[l, vals[i]||0]).sort((a,b)=>b[1]-a[1]);
    this._legend(pairs);
  }
}
